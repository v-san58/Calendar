function loadEvents(){
    return fetch("./events.json")
}


function saveEvent(date,time,event){

}

